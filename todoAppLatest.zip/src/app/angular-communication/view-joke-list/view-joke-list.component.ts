import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-joke-list',
  templateUrl: './view-joke-list.component.html',
  styleUrls: ['./view-joke-list.component.css']
})
export class ViewJokeListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
