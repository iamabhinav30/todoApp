import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-communication',
  templateUrl: './angular-communication.component.html',
  styleUrls: ['./angular-communication.component.css']
})
export class AngularCommunicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
