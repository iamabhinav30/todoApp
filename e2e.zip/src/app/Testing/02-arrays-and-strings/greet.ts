
export function greet(name) { 
  return 'Welcome ' + name; 
}
